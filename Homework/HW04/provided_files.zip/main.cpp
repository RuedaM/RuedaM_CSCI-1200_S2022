// ==================================================================
// Important Note: You are encouraged to read through this provided
//   code carefully and follow this structure.  You may modify the
//   file as needed to complete your implementation.
// ==================================================================

#include <cassert>
#include <iostream>
#include <string>
#include <list>

typedef /* FILL IN */ OrderList;
typedef /* FILL IN */ KitchenList;

//Needed for CanFillOrder()
typedef std::list <KitchenList::const_iterator> OrderFillList;

//Helper function
//Returns true if order can be fulfilled, and false otherwise. If true, then
//items_to_remove has iterators to kitchen_completed for all items that are used 
//in the order.
bool CanFillOrder(const Order &order, const KitchenList &kitchen_completed,
                  OrderFillList &items_to_remove);

int main() {
  OrderList orders;
  KitchenList food_cooking;
  KitchenList food_completed;

  std::string token;
  while (std::cin >> token) {
    if (token == "add_order") {
      int id, promised_time, n_items = 0;
      std::string next_item;
      std::list <std::string> order_items;

      std::cin >> id >> promised_time >> n_items;
      assert(n_items > 0);

      for (int i = 0; i < n_items; i++) {
        std::cin >> next_item;
        order_items.push_back(next_item);
      }

      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "add_item") {
      int cook_time = -1;
      std::string name;
      std::cin >> cook_time >> name;
      assert(cook_time >= 0);

      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "print_orders_by_time") {
      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "print_orders_by_id") {
      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "print_kitchen_is_cooking") {
      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "print_kitchen_has_completed") {
      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "run_for_time") {
      int run_time = 0;
      std::cin >> run_time;
      assert(run_time >= 0);
      /* YOU MUST FINISH THIS IMPLEMENTATION */
    } else if (token == "run_until_next") {
      std::cout << "Running until next event." << std::endl;
      /* YOU MUST FINISH THIS IMPLEMENTATION */
    }
  }

  return 0;
}


bool CanFillOrder(const Order &order, const KitchenList &kitchen_completed,
                  OrderFillList &items_to_remove) {
  items_to_remove.clear(); //We will use this to return iterators in kitchen_completed

  //Simple solution is nested for loop, but I can do better with sorting...

  std::list <std::string> order_items = order.getItems();
  order_items.sort();

  std::list<std::string>::const_iterator item_it;
  std::string prev_item = "";
  KitchenList::const_iterator kitchen_it;

  for (item_it = order_items.begin(); item_it != order_items.end(); item_it++) {
    bool found = false;

    /*Start back at beginnging of list if we're looking for something else
     *Thanks to sorting the order_items list copy, we know we're done with
       whatever kind of item prev_item was!*/
    if (prev_item != *item_it) {
      kitchen_it = kitchen_completed.begin();
      prev_item = *item_it;
    }

    /*Resume search wherever we left off last time (or beginning if it's a
    new kind of item*/
    for (; !found && kitchen_it != kitchen_completed.end(); kitchen_it++) {
      if (kitchen_it->getName() == *item_it) {
        items_to_remove.push_back(kitchen_it);
        found = true;
      }
    }

    //If we failed to satisfy an element of the order, no point continuing the search
    if (!found) {
      break;
    }
  }

  //If we couldn't fulfill the order, return an empty list
  if (items_to_remove.size() != order_items.size()) {
    items_to_remove.clear();
    return false;
  }

  return true;
}

